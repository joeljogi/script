#!/bin/bash
music_dir="/music/directory"  # Adjust the path as needed
music_file="$music_dir/hello.mp3"  # Assuming 'hello.mp3' is in the specified directory
mpg123 "$music_file"

